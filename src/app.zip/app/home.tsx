import { StyleSheet, Text, View } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { colors, ui } from '../components/sjofn-ui';

export default function HomeScreen() {
  return (
    <SafeAreaView style={styles.safe}>
      <View style={styles.container}>
        <View style={styles.brandWrap}>
          <Text style={styles.heart}>♡</Text>
          <Text style={styles.logo}>SJÖFN</Text>
        </View>
        <Text style={styles.eyebrow}>DEINE VERBINDUNGEN</Text>
        <Text style={styles.title}>Willkommen{`\n`}<Text style={styles.accent}>bei SJÖFN.</Text></Text>
        <Text style={styles.subtitle}>Die eigentliche App beginnt hier.</Text>
        <View style={styles.card}>
          <Text style={styles.cardHeart}>♡</Text>
          <Text style={styles.cardTitle}>Bereit für echte Begegnungen</Text>
          <Text style={styles.cardText}>Dein Profil ist vollständig eingerichtet.</Text>
        </View>
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: colors.cream },
  container: {
    flex: 1,
    justifyContent: 'center',
    paddingHorizontal: 28,
    maxWidth: 620,
    width: '100%',
    alignSelf: 'center',
  },
  brandWrap: { flexDirection: 'row', alignItems: 'center', gap: 9, marginBottom: 54 },
  heart: { color: colors.rose, fontSize: 27 },
  logo: {
    color: colors.ink,
    fontSize: 13,
    fontWeight: '800',
    letterSpacing: 4,
  },
  eyebrow: { ...ui.eyebrow },
  title: {
    color: colors.ink,
    fontFamily: 'Georgia',
    fontSize: 44,
    lineHeight: 48,
    fontWeight: '700',
  },
  accent: { color: colors.rose, fontStyle: 'italic' },
  subtitle: {
    color: colors.mutedDark,
    fontSize: 17,
    marginTop: 12,
  },
  card: { ...ui.card, marginTop: 36, alignItems: 'center', paddingVertical: 28 },
  cardHeart: { color: colors.rose, fontSize: 40, marginBottom: 8 },
  cardTitle: { color: colors.ink, fontFamily: 'Georgia', fontSize: 21, fontWeight: '700', textAlign: 'center' },
  cardText: { color: colors.muted, fontSize: 14, marginTop: 7, textAlign: 'center' },
});
